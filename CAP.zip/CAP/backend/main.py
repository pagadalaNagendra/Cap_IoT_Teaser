from fastapi import FastAPI, Request, HTTPException, Body
from datetime import datetime
from models import SessionLocal, SensorData
from typing import List, Optional
from sqlalchemy import desc

app = FastAPI()

def store_air_quality(sensor_values):
    try:
        db = SessionLocal()
        values = eval(sensor_values['m2m:cin']['con'])
        timestamp = datetime.strptime(sensor_values['m2m:cin']['ct'], '%Y%m%dT%H%M%S')
        
        sensor_data = SensorData(
            pm2_5=values[0],
            pm10=values[1],
            temperature=values[2],
            humidity=values[3],
            co2=values[4],
            timestamp=timestamp
        )
        
        db.add(sensor_data)
        db.commit()
        db.close()
        return True
    except Exception as e:
        print(f"Database error: {e}")
        return False

@app.post("/")
async def root(req: Request):
    body = await req.json()
    print("Received:", body)
    
    if 'm2m:sgn' in body:
        air_quality = body['m2m:sgn']['m2m:nev']['m2m:rep']
        if store_air_quality(air_quality):
            return {"status": "ok", "message": "Data stored successfully"}
    return {"status": "error", "message": "Failed to store data"}

@app.get("/air-quality/latest")
async def get_latest_reading():
    db = SessionLocal()
    try:
        latest = db.query(SensorData).order_by(desc(SensorData.timestamp)).first()
        if latest:
            return {
                "timestamp": latest.timestamp,
                "pm2_5": latest.pm2_5,
                "pm10": latest.pm10,
                "temperature": latest.temperature,
                "humidity": latest.humidity,
                "co2": latest.co2
            }
        raise HTTPException(status_code=404, detail="No data found")
    finally:
        db.close()

@app.get("/air-quality/all")
async def get_all_readings():
    db = SessionLocal()
    try:
        readings = db.query(SensorData).order_by(desc(SensorData.timestamp)).all()
        return [{
            "timestamp": reading.timestamp,
            "pm2_5": reading.pm2_5,
            "pm10": reading.pm10,
            "temperature": reading.temperature,
            "humidity": reading.humidity,
            "co2": reading.co2
        } for reading in readings]
    finally:
        db.close()

@app.put("/air-quality/{reading_id}")
async def update_reading(
    reading_id: int,
    pm2_5: Optional[float] = None,
    pm10: Optional[float] = None,
    temperature: Optional[float] = None,
    humidity: Optional[float] = None,
    co2: Optional[float] = None
):
    db = SessionLocal()
    try:
        reading = db.query(SensorData).filter(SensorData.id == reading_id).first()
        if not reading:
            raise HTTPException(status_code=404, detail="Reading not found")
        
        if pm2_5 is not None:
            reading.pm2_5 = pm2_5
        if pm10 is not None:
            reading.pm10 = pm10
        if temperature is not None:
            reading.temperature = temperature
        if humidity is not None:
            reading.humidity = humidity
        if co2 is not None:
            reading.co2 = co2
            
        db.commit()
        return {"message": "Reading updated successfully"}
    finally:
        db.close()

@app.delete("/air-quality/{reading_id}")
async def delete_reading(reading_id: int):
    db = SessionLocal()
    try:
        reading = db.query(SensorData).filter(SensorData.id == reading_id).first()
        if not reading:
            raise HTTPException(status_code=404, detail="Reading not found")
        
        db.delete(reading)
        db.commit()
        return {"message": "Reading deleted successfully"}
    finally:
        db.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8006)
