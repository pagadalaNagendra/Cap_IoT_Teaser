CREATE TABLE IF NOT EXISTS cap (
    id SERIAL PRIMARY KEY,
    pm2_5 FLOAT,
    pm10 FLOAT,
    temperature FLOAT,
    humidity FLOAT,
    co2 FLOAT,
    timestamp TIMESTAMP
);
