DB_CONFIG = {
    "dbname": "cap",
    "user": "postgres",
    "password": "postgres",
    "host": "localhost",
    "port": "5432"
}
