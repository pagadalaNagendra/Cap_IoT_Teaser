from fastapi import FastAPI
import requests
import json
import random
import asyncio

app = FastAPI()

# oneM2M CSE configuration
CSE_URL = "http://127.0.0.1:8080/~/in-cse/in-name/AE-AQ/AQ-MG00-00/Data"
HEADERS = {
    "X-M2M-Origin": "admin:admin",
    "Content-Type": "application/json;ty=4"
}

# Function to generate random sensor data
def generate_sensor_data():
    pm25 = round(random.uniform(10, 50), 2)
    pm10 = round(random.uniform(20, 60), 2)
    temperature = round(random.uniform(20, 35), 2)
    humidity = round(random.uniform(40, 70), 2)
    co2 = round(random.uniform(30, 100), 2)

    payload = {
        "m2m:cin": {
            "lbl": ["pm2.5", "pm10", "temperature", "humidity", "co2"],
            "con": f"[{pm25},{pm10},{temperature},{humidity},{co2}]"
        }
    }
    return payload

# Background task to continuously post data
async def post_data_continuously():
    while True:
        payload = generate_sensor_data()
        try:
            response = requests.post(CSE_URL, headers=HEADERS, data=json.dumps(payload))
            if response.status_code in [200, 201]:
                print("✅ Data posted:", payload)
            else:
                print("⚠️ Failed:", response.status_code, response.text)
        except Exception as e:
            print("❌ Error:", e)

        await asyncio.sleep(20)  # post every 5 seconds

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(post_data_continuously())

@app.get("/")
def read_root():
    return {"status": "FastAPI is running and posting sensor data continuously."}
